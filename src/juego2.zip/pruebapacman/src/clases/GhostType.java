package clases;

public enum GhostType {
    CLYDE,
    BLINKY,
    INKY,
    PINKY
}
